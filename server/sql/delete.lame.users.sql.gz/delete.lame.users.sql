delete from active_user where user not in ('krbnc2n5da', '6irh2g0hua', 'czlkd15v3s');
delete from active_user_log where user not in ('krbnc2n5da', '6irh2g0hua', 'czlkd15v3s');
delete from user_email where user not in ('krbnc2n5da', '6irh2g0hua', 'czlkd15v3s');
delete from user where id not in ('krbnc2n5da', '6irh2g0hua', 'czlkd15v3s');